import React from 'react'
import { Link } from 'react-router-dom'


const Questions = ({questions}) => {
  return (
    <div className='display-question-container'>
        
         <div className='display-votes-ans'>
            <p>{questions.upVotes-questions.downVotes}</p>
            <p>votes</p>
        </div>  
        <div className='display-votes-ans'>
            <p>{questions.noofAnswers}</p>
            <p>answers</p>
        </div> 
        <div className='display-question-details'>
            <Link to={`/Questions/${questions._id}`} className='question-title-link'>
                {questions.questionTitle}
            </Link>
        </div>
        <div className='display-tags-time'>
            <div className='display-tags'>
                {
                    questions.questionTag.map((tag)=>(
                        <p key={tag}>{tag}</p>
                    ))
                }
            </div>
            <p className='display-time'>
                asked{questions.askedOn}{questions.userPosted}
            </p>
        </div>
     </div> 

  )
}

export default Questions
