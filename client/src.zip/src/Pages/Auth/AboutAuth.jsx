import React from 'react'
import './Auth.css'

const AboutAuth = () => {
  return (
    <div className='auth-container-1'>
      <h1>Join the stack overflow Community</h1>
    </div>
  )
}

export default AboutAuth
