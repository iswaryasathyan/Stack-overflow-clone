import authReducer from "./auth";
import { combineReducers } from "redux";
import currentUserReducer from './currentUser'
import questionsReducer from './questions'

export default combineReducers({
    authReducer,currentUserReducer,questionsReducer
})